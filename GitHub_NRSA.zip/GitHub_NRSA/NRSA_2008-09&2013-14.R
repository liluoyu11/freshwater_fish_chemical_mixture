##NRSA 2008-2009 & 2013-2014 dataset
install.packages('corrplot')
library('corrplot')
install.packages("Hmisc")
library("Hmisc")
library(corrplot)
library(readxl)
#set working directory setwd("/")
#BD stands for benthic dweller fish
BD<- read_excel("08-09BD.xlsx")
Predator<- read_excel("08-09Predator.xlsx")
head(urbanBD)

head(nonurbanBD)

# ++++++++++++++++++++++++++++
# flattenCorrMatrix
# ++++++++++++++++++++++++++++
# cormat : matrix of the correlation coefficients
# pmat : matrix of the correlation p-values

flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}

library(corrplot)

BD_rcorr<-psych::corr.test(BD, method="spearman", adjust="none")
Predator_rcorr<-psych::corr.test(Predator, method="spearman", adjust="none")

flattenCorrMatrix(BD_rcorr$r,BD_rcorr$p)
flattenCorrMatrix(Predator_rcorr$r,Predator_rcorr$p)

corrplot(BD_rcorr$r, type="upper", order="hclust", 
         p.mat = BD_rcorr$p, sig.level = 0.05, insig = "blank")
corrplot(Predator_rcorr$r, type="upper",  order="hclust", 
         p.mat = Predator_rcorr$p, sig.level = 0.05, insig = "blank")

##boxplot packages
install.packages("reshape2") # Install reshape2 package
library("reshape2")        # Load reshape2

install.packages("ggplot2")         # Install ggplot2 package
library("ggplot2")   # Load ggplot2
install.packages("lattice")                                  # Install lattice package
library("lattice")

#boxplot of predator fish NRSA 2008-2009
Predator1<-read_csv("08-09Predator.csv")
head(Predator1)
Predator1_long<-melt(Predator1)
head(Predator1_long)
Predator1box<-ggplot(Predator1_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in predator fish from NRSA 2008-2009") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Predator1box
Predator1box + scale_y_continuous(trans='log10')

#boxplot of benthic dweller NRSA 2008-2009
BD1<-read_csv("08-09BD.csv")
head(BD1)
BD1_long<-melt(BD1)
head(BD1_long)
BD1box<-ggplot(BD1_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in benthic-dweller fish from NRSA 2008-2009") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BD1box
BD1box + scale_y_continuous(trans='log10')

#boxplot of predator fish NRSA 2013-2014
Predator2<-read_csv("13-14Predator.csv")
head(Predator2)
Predator2_long<-melt(Predator2)
head(Predator2_long)
Predator2box<-ggplot(Predator2_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in predator fish from NRSA 2013-2014") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Predator2box + scale_y_continuous(trans='log10')

#boxplot benthic dweller fish of NRSA 2013-2014
BD2<-read_csv("13-14BD.csv")
head(BD2)
BD2_long<-melt(BD2)
head(BD2_long)
BD2box<-ggplot(BD2_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in benthic-dweller fish from NRSA 2008-2009") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BD2box + scale_y_continuous(trans='log10')


##boxplot predator fish during two NRSA periods
PDA<- read_csv("Predator_NRSA.csv")
head(PDA)

PDA_long <- melt(PDA, id = "Dataset")    
head(PDA_long)
PDAbox<-ggplot(PDA_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in predator fishes from monitoring NRSA 2008-2014") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
PDAbox + scale_y_continuous(trans='log10')+
  scale_color_manual(values=c("#999999","purple")) 


##boxplot benthic dweller during two NRSA periods
BDA<- read_csv("BD_NRSA.csv")
head(BDA)

BDA_long <- melt(BDA, id = "Dataset")    
head(BDA_long)
BDAbox<-ggplot(BDA_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in benthic-dweller fishes from monitoring NRSA 2008-2014") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BDAbox + scale_y_continuous(trans='log10')+
  scale_color_manual(values=c("#999999","purple")) 
