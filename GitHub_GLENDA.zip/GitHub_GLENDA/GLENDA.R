library(tidyverse)

library(readxl)
library(corrplot)
library("Hmisc")
library(psych)


#set working directory setwd("")#

head(FirstPeriod_corrplot,10)

flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}

FirstPeriod_corrplot<- read_excel("GLENDA1999-2003.xlsx")
FP_rcorr<-corr.test(FirstPeriod_corrplot[, 11:22,with=FALSE],method="spearman", adjust="none")

flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)
corrplot(FP_rcorr$r, type="upper", order="hclust", 
         p.mat = FP_rcorr$p, sig.level = 0.05, insig = "blank")
FP_check<-flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)

SecondPeriod_corrplot<- read_excel("GLENDA2004-2009.xlsx")
SP_rcorr<-corr.test(SecondPeriod_corrplot[, 11:21,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(SP_rcorr$r,SP_rcorr$p)
corrplot(SP_rcorr$r, type="upper", order="hclust", 
         p.mat = SP_rcorr$p, sig.level = 0.05, insig = "blank")

ThirdPeriod_corrplot<- read_excel("GLENDA2010-2018.xlsx")
TP_rcorr<-corr.test(ThirdPeriod_corrplot[, 11:23,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(TP_rcorr$r,TP_rcorr$p)
corrplot(TP_rcorr$r, type="upper", order="hclust", 
         p.mat = TP_rcorr$p, sig.level = 0.05, insig = "blank")


##removed an outlier of with extremely high PFAS total
TP_corrplot<- read_excel("GLENDA2010-2018.xlsx")
TP_rcorr2<-corr.test(TP_corrplot[, 11:23,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(TP_rcorr2$r,TP_rcorr2$p)
corrplot(TP_rcorr2$r, type="upper", order="hclust", 
         p.mat = TP_rcorr2$p, sig.level = 0.05, insig = "blank")



##Walleye
FirstPeriod_corrplot<- read_excel("GLENDA1999-2003_24nov2022.xlsx")
#4,4'-DDT, g-HCH and Mirex removed due to insufficient numbers
FP_rcorr<-corr.test(FirstPeriod_corrplot[, 11:22,with=FALSE],method="spearman", adjust="none")

flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)
corrplot(FP_rcorr$r, type="upper", order="hclust", 
         p.mat = FP_rcorr$p, sig.level = 0.05, insig = "blank")
FP_check<-flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)

SecondPeriod_corrplot<- read_excel("GLENDA2004-2009_25nov2022.xlsx")
#g-HCH removed due to data imbalance
SP_rcorr<-corr.test(SecondPeriod_corrplot[, 11:26,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(SP_rcorr$r,SP_rcorr$p)
corrplot(SP_rcorr$r, type="upper", order="hclust", 
         p.mat = SP_rcorr$p, sig.level = 0.05, insig = "blank")

ThirdPeriod_corrplot<- read_excel("GLENDA2010-2018_25nov2022.xlsx")
TP_rcorr<-corr.test(ThirdPeriod_corrplot[, 11:28,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(TP_rcorr$r,TP_rcorr$p)
corrplot(TP_rcorr$r, type="upper", order="hclust", 
         p.mat = TP_rcorr$p, sig.level = 0.05, insig = "blank")

##Lake Trout
FirstPeriod_corrplot<- read_excel("GLENDA1999-2003_24nov2022.xlsx")
FP_rcorr<-corr.test(FirstPeriod_corrplot[, 11:27,with=FALSE],method="spearman", adjust="none")

flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)
corrplot(FP_rcorr$r, type="upper", order="hclust", 
         p.mat = FP_rcorr$p, sig.level = 0.05, insig = "blank")
FP_check<-flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)

SecondPeriod_corrplot<- read_excel("GLENDA2004-2009_25nov2022.xlsx")
SP_rcorr<-corr.test(SecondPeriod_corrplot[, 11:28,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(SP_rcorr$r,SP_rcorr$p)
corrplot(SP_rcorr$r, type="upper", order="hclust", 
         p.mat = SP_rcorr$p, sig.level = 0.05, insig = "blank")

ThirdPeriod_corrplot<- read_excel("GLENDA2010-2018_25nov2022.xlsx")
TP_rcorr<-corr.test(ThirdPeriod_corrplot[, 11:30,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(TP_rcorr$r,TP_rcorr$p)
corrplot(TP_rcorr$r, type="upper", order="hclust", 
         p.mat = TP_rcorr$p, sig.level = 0.05, insig = "blank")

##boxplot of walleye from NLFTS and GLENDA during 1999-2003


install.packages("reshape2") # Install reshape2 package
library("reshape2")        # Load reshape2
 
install.packages("ggplot2")         # Install ggplot2 package
library("ggplot2")   # Load ggplot2
install.packages("lattice")                                  # Install lattice package
library("lattice")

BW<- read_csv("Walleye_2_datasets.csv")
head(BW)

BW_long <- melt(BW, id = "Dataset")    
head(BW_long)
BWbox<-ggplot(BW_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
    ggtitle("Boxplot of contaminants in walleye from GLENDA & NLFTS monitoring 1999-2003") +
    xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(size=8))
BWbox + scale_y_continuous(trans='log10')+
  scale_color_manual(values=c("#999999","purple")) 

#boxplot of lake trout GLENDA 1999-2003
Trout1<-read_csv("Trout_1999-2003.csv")
head(Trout1)
Trout1_long<-melt(Trout1)
head(Trout1_long)
Trout1box<-ggplot(Trout1_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in lake trout from GLENDA 1999-2003") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Trout1box
Trout1box + scale_y_continuous(trans='log10')
###  ggplot(data_long, aes(x = variable, y = value)) +            # Applying ggplot function
####  geom_boxplot()

#boxplot of walleye GLENDA 1999-2003
Walleye1<-read_csv("Walleye_1999-2003.csv")
head(Walleye1)
Walleye1_long<-melt(Walleye1)
head(Walleye1_long)
Walleye1box<-ggplot(Walleye1_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of walleye from GLENDA 1999-2003") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Walleye1box
Walleye1box + scale_y_continuous(trans='log10')


##adjusted Walleye two datasets comparison after correcting GLENDA 1999-2003 PCB values from possibly ng/kg to ug/kg
BWA<- read_csv("Walleye_2_datasets_adjusted.csv")
head(BWA)

BWA_long <- melt(BWA, id = "Dataset")    
head(BWA_long)
BWAbox<-ggplot(BWA_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of walleye contaminant in local&national datasets") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(size=8))
BWAbox + scale_y_continuous(trans='log10')

#boxplot of lake trout GLENDA 2004-2009
Trout2<-read_csv("Trout_2004-2009.csv")
head(Trout2)
Trout2_long<-melt(Trout2)
head(Trout2_long)
Trout2box<-ggplot(Trout2_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of lake trout from GLENDA 2004-2009") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Trout2box
Trout2box + scale_y_continuous(trans='log10')
###  ggplot(data_long, aes(x = variable, y = value)) +            # Applying ggplot function
####  geom_boxplot()

#boxplot of walleye GLENDA 2004-2009
Walleye2<-read_csv("Walleye_2004-2009.csv")
head(Walleye2)
Walleye2_long<-melt(Walleye2)
head(Walleye2_long)
Walleye2box<-ggplot(Walleye2_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of walleye from GLENDA 2004-2009") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Walleye2box
Walleye2box + scale_y_continuous(trans='log10')


#boxplot of lake trout GLENDA 2010-2018
Trout3<-read_csv("Trout_2010-2018.csv")
head(Trout3)
Trout3_long<-melt(Trout3)
head(Trout3_long)
Trout3box<-ggplot(Trout3_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of lake trout from GLENDA 2010-2018") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Trout3box + scale_y_continuous(trans='log10')
###  ggplot(data_long, aes(x = variable, y = value)) +            # Applying ggplot function
####  geom_boxplot()

#boxplot of walleye GLENDA 2010-2018
Walleye3<-read_csv("Walleye_2010-2018.csv")
head(Walleye3)
Walleye3_long<-melt(Walleye3)
head(Walleye3_long)
Walleye3box<-ggplot(Walleye3_long, aes(x = variable, y = value)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of walleye from GLENDA 2010-2018") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Walleye3box + scale_y_continuous(trans='log10')

##boxplot of walleye from NLFTS during 1999-2018, 3 different periods

install.packages("reshape2") # Install reshape2 package
library("reshape2")        # Load reshape2

install.packages("ggplot2")         # Install ggplot2 package
library("ggplot2")   # Load ggplot2
install.packages("lattice")                                  # Install lattice package
library("lattice")

BAW<- read_csv("Walleye_all.csv")
head(BAW)
# ANOVA of chemicals including Hg, dioxin-like PCBs in GLENDA walleye
one.way <- aov(Hg ~ Dataset, data = BAW)
summary(one.way)
one.way$coefficients

one.way <- aov(`Total PCBs` ~ Dataset, data = BAW)
summary(one.way)

one.way <- aov(`Dioxin-like PCBs (7)` ~ Dataset, data = BAW)
summary(one.way)

BAW_long <- melt(BAW, id = "Dataset")    
head(BAW_long)
BAWbox<-ggplot(BAW_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in walleye from GLENDA monitoring 1999-2018") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BAWbox + scale_y_continuous(trans='log10') + 
  scale_color_manual(values=c("#999999","purple","orange"))  

##boxplot of lake trout from NLFTS during 1999-2018, 3 different periods
BALT<- read_csv("Trout_all.csv")
head(BALT)

# ANOVA of chemicals including Hg, dioxin-like PCBs in GLENDA trout
one.way <- aov(Hg ~ Dataset, data = BALT)
summary(one.way)

one.way <- aov(`Dioxin-like PCBs (7)` ~ Dataset, data = BALT)
summary(one.way)

one.way <- aov(`Total PCBs` ~ Dataset, data = BALT)
summary(one.way)

# box plot
BALT_long <- melt(BALT, id = "Dataset")    
head(BALT_long)
BALTbox<-ggplot(BALT_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in lake trout from GLENDA monitoring 1999-2018") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BALTbox + scale_y_continuous(trans='log10')+ 
  scale_color_manual(values=c("#999999","purple","orange"))  
