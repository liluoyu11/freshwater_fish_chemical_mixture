devtools::install_github("r-lib/conflicted")
library(conflicted)
library(dplyr)

install.packages('corrplot')
library('corrplot')
install.packages("Hmisc")
library("Hmisc")
library(corrplot)
library(readxl)
library(tidyverse)
library(psych)

#setting up working directory- setwd("/")


#define a correlation matrix for plotting
flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}

#Extract from source data for NCCA Great Lakes 2010 Pelagic fish
First_corrplot<- read_excel("NCCA-GL2010_Pelagic.xlsx")
head(First_corrplot,10)
FP_rcorr<-corr.test(First_corrplot,method="spearman", adjust="none")

flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)
corrplot(FP_rcorr$r, type="upper", order="hclust", 
         p.mat = FP_rcorr$p, sig.level = 0.05, insig = "blank")
FP_check<-flattenCorrMatrix(FP_rcorr$r,FP_rcorr$p)

#Extract from source data for NCCA Great Lakes 2010 benthic dweller fish
FirstB_corrplot<- read_excel("NCCA-GL2010_Benthic.xlsx")
head(FirstB_corrplot,10)
FPB_rcorr<-corr.test(FirstB_corrplot,method="spearman", adjust="none")

flattenCorrMatrix(FPB_rcorr$r,FPB_rcorr$p)
corrplot(FPB_rcorr$r, type="upper", order="hclust", 
         p.mat = FPB_rcorr$p, sig.level = 0.05, insig = "blank")
FPB_check<-flattenCorrMatrix(FPB_rcorr$r,FPB_rcorr$p)

#Extract from source data for NCCA Great Lakes 2015 Pelagic fish
Second_corrplot<- read_excel("NCCA-GL-2015-Pelagic.xlsx")
head(Second_corrplot,10)
SP_rcorr<-corr.test(Second_corrplot,method="spearman", adjust="none")

flattenCorrMatrix(SP_rcorr$r,SP_rcorr$p)
corrplot(SP_rcorr$r, type="upper", order="hclust", 
         p.mat = FP_rcorr$p, sig.level = 0.05, insig = "blank")
SP_check<-flattenCorrMatrix(SP_rcorr$r,SP_rcorr$p)

#Extract from source data for NCCA Great Lakes 2015 benthic dweller fish
SecondB_corrplot<- read_excel("NCCA-GL-2015-Benthic.xlsx")
head(SecondB_corrplot,10)
SPB_rcorr<-corr.test(SecondB_corrplot,method="spearman", adjust="none")

flattenCorrMatrix(SPB_rcorr$r,SPB_rcorr$p)
corrplot(SPB_rcorr$r, type="upper", order="hclust", 
         p.mat = SPB_rcorr$p, sig.level = 0.05, insig = "blank")
SPB_check<-flattenCorrMatrix(SPB_rcorr$r,SPB_rcorr$p)

#Extract from source data for NCCA Great Lakes 2020 Pelagic fish
PL_corrplot<- read_excel("NCCA-GL-2020-Pelagic.xlsx")
head(PL_corrplot,10)
PL_rcorr<-corr.test(PL_corrplot,method="spearman", adjust="none")

flattenCorrMatrix(PL_rcorr$r,PL_rcorr$p)
corrplot(PL_rcorr$r, type="upper", order="hclust", 
         p.mat = PL_rcorr$p, sig.level = 0.05, insig = "blank")
PL_check<-flattenCorrMatrix(PL_rcorr$r,PL_rcorr$p)

#Extract from source data for NCCA Great Lakes 2020 benthic dweller fish
ThirdB_corrplot<- read_excel("NCCA-GL-2020-Benthic.xlsx")
head(ThirdB_corrplot,10)
TPB_rcorr<-corr.test(ThirdB_corrplot,method="spearman", adjust="none")

flattenCorrMatrix(TPB_rcorr$r,TPB_rcorr$p)
corrplot(TPB_rcorr$r, type="upper", order="hclust", 
         p.mat = TPB_rcorr$p, sig.level = 0.05, insig = "blank")
TPB_check<-flattenCorrMatrix(TPB_rcorr$r,TPB_rcorr$p)

#Extract from source data for NCCA Great Lakes 2010, 2015, 2020 walleye fish
WL_corrplot<- read_excel("Walleye-NCCA-GL-2010-15-20.xlsx")
head(WL_corrplot,10)
WL_rcorr<-corr.test(WL_corrplot,method="spearman", adjust="none")

flattenCorrMatrix(WL_rcorr$r,WL_rcorr$p)
corrplot(WL_rcorr$r, type="upper", order="hclust", 
         p.mat = WL_rcorr$p, sig.level = 0.05, insig = "blank")
WL_check<-flattenCorrMatrix(WL_rcorr$r,WL_rcorr$p)

#Extract from source data for NCCA Great Lakes 2010, 2015, 2020 pelagic fish
PL_corrplot<- read_excel("Pelagic-NCCA-GL-2010-15-20.xlsx")
head(PL_corrplot,10)
PL_rcorr<-corr.test(PL_corrplot[, 1:17,with=FALSE],method="spearman", adjust="none")

flattenCorrMatrix(PL_rcorr$r,PL_rcorr$p)
corrplot(PL_rcorr$r, type="upper", order="hclust", 
         p.mat = PL_rcorr$p, sig.level = 0.05, insig = "blank")
PL_check<-flattenCorrMatrix(PL_rcorr$r,PL_rcorr$p)

#Extract from source data for NCCA Great Lakes 2010, 2015, 2020 benthic fish
BE_corrplot<- read_excel("Benthic-NCCA-GL-2010-15-20.xlsx")
head(BE_corrplot,10)
BE_rcorr<-corr.test(BE_corrplot[, 1:17,with=FALSE],method="spearman", adjust="none")

flattenCorrMatrix(BE_rcorr$r,BE_rcorr$p)
corrplot(BE_rcorr$r, type="upper", order="hclust", 
         p.mat = BE_rcorr$p, sig.level = 0.05, insig = "blank")
BE_check<-flattenCorrMatrix(BE_rcorr$r,BE_rcorr$p)

##boxplot of walleye from NLFTS 1999-2003 and NCCA-GL 2010+2015+2020


install.packages("reshape2") # Install reshape2 package
library("reshape2")        # Load reshape2

install.packages("ggplot2")         # Install ggplot2 package
library("ggplot2")   # Load ggplot2
install.packages("lattice")          # Install lattice package
library("lattice")
library(tidyverse)
library(readxl) 
install.packages("reshape")
BW<- read_excel("Walleye_new_2_datasets.xlsx")
head(BW)

BW_long <- melt(BW, id = "Dataset")    
head(BW_long)
BWbox<-ggplot(BW_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in walleye from NLFTS 1999-2003 and NCCA-GL 2010+2015+2020") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(size=8))
BWbox + scale_y_continuous(trans='log10')+
  scale_color_manual(values=c("#999999","purple")) 

# ANOVA of chemicals including Hg, dioxin-like PCBs, NLFTS vs NCCA-GL
one.way <- aov(Hg ~ Dataset, data = BW)
summary(one.way)

one.way <- aov(`Dioxin-like PCBs (12)`~ Dataset, data = BW)
summary(one.way)

one.way <- aov(`Total PCBs (209)`~ Dataset, data = BW)
summary(one.way)

# box-plot of pelagic fish NCCA-GL 2010-15-20
Pelagic1<-read_excel("Pelagic-NCCA-GL-2010-15-20.xlsx")
head(Pelagic1)
Pelagic1_long<-melt(Pelagic1)
head(Pelagic1_long)
Pelagic1box<-ggplot(Pelagic1_long, aes(x = variable, y = value, color=Dataset)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in predator fishes from NCCA-GL 2010/2015/2020") +
  xlab("Fish Contaminant") + ylab("μg/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Pelagic1box + scale_y_continuous(trans='log10')+ 
  scale_color_manual(values=c("#999999","purple","orange")) 

# ANOVA of chemicals including Hg, dioxin-like PCBs in NCCA-GL predator fish
Pelagic1<-read_excel("Pelagic-NCCA-GL-2010-15-20.xlsx")
head(Pelagic1)

one.way <- aov(Hg ~ Dataset, data = Pelagic1)
summary(one.way)

one.way <- aov(`Dioxin-like PCBs (12)` ~ Dataset, data = Pelagic1)
summary(one.way)

one.way <- aov(`Total PCBs (209)` ~ Dataset, data = Pelagic1)
summary(one.way)

one.way <- aov(`Total PFAS*` ~ Dataset, data = Pelagic1)
summary(one.way)

#boxplot of benthic fish NCCA-GL 2010-15-20
Benthic1<-read_excel("Benthic-NCCA-GL-2010-15-20.xlsx")
head(Benthic1)
Benthic1_long<-melt(Benthic1)
head(Benthic1_long)
Benthic1box<-ggplot(Benthic1_long, aes(x = variable, y = value, color=Dataset)) +            # Applying ggplot function
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in benthic dweller fishes from NCCA-GL 2010/2015/2020") +
  xlab("Fish Contaminant") + ylab("μg/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
Benthic1box + scale_y_continuous(trans='log10')+ 
  scale_color_manual(values=c("#999999","purple","orange")) 

# ANOVA of chemicals including Hg, dioxin-like PCBs in NCCA-GL benthic fish
Benthic1<-read_excel("Benthic-NCCA-GL-2010-15-20.xlsx")
head(Benthic1)

one.way <- aov(Hg ~ Dataset, data = Benthic1)
summary(one.way)

one.way <- aov(`Dioxin-like PCBs (12)` ~ Dataset, data = Benthic1)
summary(one.way)

one.way <- aov(`Total PCBs (209)` ~ Dataset, data = Benthic1)
summary(one.way)

one.way <- aov(`Total PFAS*` ~ Dataset, data = Benthic1)
summary(one.way)

#boxplot of NCCA-GL 2010/15/20 and GLENDA 2010-2018
BW<- read_excel("Walleye_new_2_datasets.xlsx")
head(BW)

BW_long <- melt(BW, id = "Dataset")    
head(BW_long)
BWbox<-ggplot(BW_long, aes(x = variable, y = value, color = Dataset)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in walleye from NLFTS 1999-2003 and NCCA-GL 2010+2015+2020") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(size=8))
BWbox + scale_y_continuous(trans='log10')+
  scale_color_manual(values=c("#999999","purple")) 