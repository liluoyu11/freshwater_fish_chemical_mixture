##NLFTS1999-2003 dataset 28nov2022
install.packages('corrplot')
library('corrplot')
install.packages("Hmisc")
library("Hmisc")
library(corrplot)
library(readxl)

#set working directory setwd("")#


# ++++++++++++++++++++++++++++
# flattenCorrMatrix
# ++++++++++++++++++++++++++++
# cormat : matrix of the correlation coefficients
# pmat : matrix of the correlation p-values

flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}

library(psych)

Pelagic<- read_excel("Pelagic.xlsx")
head(Pelagic)
#correlation plot NLFTS1999-2003
Pelagic_rcorr<-psych::corr.test(Pelagic, method="spearman", adjust="none")
flattenCorrMatrix(Pelagic_rcorr$r,Pelagic_rcorr$p)
corrplot(Pelagic_rcorr$r, type="upper", order="hclust", 
         p.mat = Pelagic_rcorr$p, sig.level = 0.05, insig = "blank")

Pelagic1999<- read_excel("Pelagic1999.xlsx")
head(Pelagic1999)
Pelagic1999_rcorr<-psych::corr.test(Pelagic1999, method="spearman", adjust="none")
flattenCorrMatrix(Pelagic1999_rcorr$r,Pelagic1999_rcorr$p)
corrplot(Pelagic1999_rcorr$r, type="upper", order="hclust", 
         p.mat = Pelagic1999_rcorr$p, sig.level = 0.05, insig = "blank")

Pelagic2000<- read_excel("Pelagic2000.xlsx")
head(Pelagic2000)
Pelagic2000_rcorr<-psych::corr.test(Pelagic2000, method="spearman", adjust="none")
flattenCorrMatrix(Pelagic2000_rcorr$r,Pelagic2000_rcorr$p)
corrplot(Pelagic2000_rcorr$r, type="upper", order="hclust", 
         p.mat = Pelagic2000_rcorr$p, sig.level = 0.05, insig = "blank")

Pelagic2001<- read_excel("Pelagic2001.xlsx")
head(Pelagic2001)
Pelagic2001_rcorr<-psych::corr.test(Pelagic2001, method="spearman", adjust="none")
flattenCorrMatrix(Pelagic2001_rcorr$r,Pelagic2001_rcorr$p)
corrplot(Pelagic2001_rcorr$r, type="upper", order="hclust", 
         p.mat = Pelagic2001_rcorr$p, sig.level = 0.05, insig = "blank")

Pelagic2002<- read_excel("Pelagic2002.xlsx")
head(Pelagic2002)
Pelagic2002_rcorr<-psych::corr.test(Pelagic2002, method="spearman", adjust="none")
flattenCorrMatrix(Pelagic2002_rcorr$r,Pelagic2002_rcorr$p)
corrplot(Pelagic2002_rcorr$r, type="upper", order="hclust", 
         p.mat = Pelagic2002_rcorr$p, sig.level = 0.05, insig = "blank")

Pelagic2003<- read_excel("Pelagic2003.xlsx")
head(Pelagic2003)
Pelagic2003_rcorr<-psych::corr.test(Pelagic2003, method="spearman", adjust="none")
flattenCorrMatrix(Pelagic2003_rcorr$r,Pelagic2003_rcorr$p)
corrplot(Pelagic2003_rcorr$r, type="upper", order="hclust", 
         p.mat = Pelagic2003_rcorr$p, sig.level = 0.05, insig = "blank")


Benthic<- read_excel("Benthic.xlsx")
head(Benthic)
Benthic_rcorr<-psych::corr.test(Benthic, method="spearman", adjust="none")
flattenCorrMatrix(Benthic_rcorr$r,Benthic_rcorr$p)
corrplot(Benthic_rcorr$r, type="upper",  order="hclust", 
         p.mat = Benthic_rcorr$p, sig.level = 0.05, insig = "blank")

Benthic1999<- read_excel("Benthic1999.xlsx")
head(Benthic1999)
Benthic1999_rcorr<-psych::corr.test(Benthic1999, method="spearman", adjust="none")
flattenCorrMatrix(Benthic1999_rcorr$r,Benthic1999_rcorr$p)
corrplot(Benthic1999_rcorr$r, type="upper",  order="hclust", 
         p.mat = Benthic1999_rcorr$p, sig.level = 0.05, insig = "blank")

Benthic2000<- read_excel("Benthic2000.xlsx")
head(Benthic2000)
Benthic2000_rcorr<-psych::corr.test(Benthic2000, method="spearman", adjust="none")
flattenCorrMatrix(Benthic2000_rcorr$r,Benthic2000_rcorr$p)
corrplot(Benthic2000_rcorr$r, type="upper",  order="hclust", 
         p.mat = Benthic2000_rcorr$p, sig.level = 0.05, insig = "blank")

Benthic2001<- read_excel("Benthic2001.xlsx")
head(Benthic2001)
Benthic2001_rcorr<-psych::corr.test(Benthic2001, method="spearman", adjust="none")
flattenCorrMatrix(Benthic2001_rcorr$r,Benthic2001_rcorr$p)
corrplot(Benthic2001_rcorr$r, type="upper",  order="hclust", 
         p.mat = Benthic2001_rcorr$p, sig.level = 0.05, insig = "blank")

Benthic2002<- read_excel("Benthic2002.xlsx")
head(Benthic2002)
Benthic2002_rcorr<-psych::corr.test(Benthic2002, method="spearman", adjust="none")
flattenCorrMatrix(Benthic2002_rcorr$r,Benthic2002_rcorr$p)
corrplot(Benthic2002_rcorr$r, type="upper",  order="hclust", 
         p.mat = Benthic2002_rcorr$p, sig.level = 0.05, insig = "blank")

Benthic2003<- read_excel("Benthic2003.xlsx")
head(Benthic2003)
Benthic2003_rcorr<-psych::corr.test(Benthic2003, method="spearman", adjust="none")
flattenCorrMatrix(Benthic2003_rcorr$r,Benthic2003_rcorr$p)
corrplot(Benthic2003_rcorr$r, type="upper",  order="hclust", 
         p.mat = Benthic2003_rcorr$p, sig.level = 0.05, insig = "blank")

Walleye<- read_excel("Walleye.xlsx")
head(Walleye)
Walleye_rcorr<-psych::corr.test(Walleye[, 1:15,with=FALSE], method="spearman", adjust="none")
flattenCorrMatrix(Walleye_rcorr$r,Walleye_rcorr$p)
corrplot(Walleye_rcorr$r, type="upper",  order="hclust", 
         p.mat = Walleye_rcorr$p, sig.level = 0.05, insig = "blank")

LakeTrout<- read_excel("LakeTrout.xlsx")
head(LakeTrout)
LakeTrout_rcorr<-psych::corr.test(LakeTrout, method="spearman", adjust="none")
flattenCorrMatrix(LakeTrout_rcorr$r,LakeTrout_rcorr$p)
corrplot(LakeTrout_rcorr$r, type="upper",  order="hclust", 
         p.mat = LakeTrout_rcorr$p, sig.level = 0.05, insig = "blank")

###boxplot packages
install.packages("reshape2") # Install reshape2 package
library("reshape2")        # Load reshape2

install.packages("ggplot2")         # Install ggplot2 package
library("ggplot2")   # Load ggplot2
install.packages("lattice")                                  # Install lattice package
library("lattice")

##boxplot of predator 1999-2003
BP<- read_csv("Pelagic.csv")
head(BP)

BP_long <- melt(BP)    
head(BP_long)
BPbox<-ggplot(BP_long, aes(x = variable, y = value)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in pelagic fish from NLFTS monitoring 1999-2003") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BPbox + scale_y_continuous(trans='log10')

##boxplot of benthic-dweller 1999-2003
BBD<- read_csv("Benthic.csv")
head(BBD)

BBD_long <- melt(BBD)    
head(BBD_long)
BBDbox<-ggplot(BBD_long, aes(x = variable, y = value)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in benthic-dweller fish from NLFTS monitoring 1999-2003") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BBDbox + scale_y_continuous(trans='log10')

##boxplot of all NLFTS fishes 1999-2003
BAF<- read_csv("NLFTS_all.csv")
head(BAF)

BAF_long <- melt(BAF, id = "Type")    
head(BAF_long)
BAFbox<-ggplot(BAF_long, aes(x = variable, y = value, color = Type)) +  
  geom_boxplot()+ 
  ggtitle("Boxplot of contaminants in fish from NLFTS monitoring 1999-2003") +
  xlab("Fish Contaminant") + ylab("ug/kg ww")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
BAFbox + scale_y_continuous(trans='log10')+
  scale_color_manual(values=c("#999999","purple"))  
